import base64, json, os, time
from pathlib import Path
from Crypto.Hash import SHA256
from ..utils import logger as log
from ..utils.logger import CTX, notify_user
from ..utils.network import api_post, handle_resp
from ..utils.crypto import canonical_json
from ..utils.agent_client import AgentClient

"""
Structure de account_state.json :

{
  "username": "...",          // string (en clair)
  "salt": "...",              // b64
  "public_key": "...",        // b64
  "private_key": {
    "enc": "...",             // b64
    "nonce": "...",           // b64
    "tag": "..."              // b64
  },
  "session": {
    "enc": "...",             // b64
    "nonce": "...",           // b64
    "tag": "..."              // b64
  }
  "current_vault": "..."      // UUID vault sélectionné (optionnel)
  "integrity": {
    "value": "...",           // b64
    "algo": "HMAC-SHA256"     // string
  }
}
"""

APP_DIR = Path.home() / ".protopass" / "client_data"
MAX_UNLOCK_ATTEMPTS = 3
SESSION_VALIDITY_TTL = 2  # secondes pendant lesquelles on réutilise une vérification positive

class AccountState:
    """
    Stocke l'état local du compte : informations persistantes associées à l'utilisateur
    (username, session_id, clé publique, etc.).
    """

    # Champs mémoire volatile (non sauvegardés) utile pour le shell interactif
    _cached_username = None  # Pour des questions de performance (évite de relire le fichier à chaque fois)
    _cached_session_id = None  # Pour des questions de performance
    _cached_integrations = {} # Cache mémoire des intégrations chargées
    _cached_public_key = None  # Pour des questions de performance
    _private_key = None  # Pour des questions de sécurité
    _vault_keys = {}  # Cache mémoire des clés de vault déchiffrées
    _integrations_block = None  # Bloc chiffré des intégrations (persisté)

    # Cache de l'id de vault sélectionné, et flag si l'id a besoin d'être loadé du disk (pour CLI)
    _current_vault_id = None
    _current_vault_loaded = False
    _current_vault_name = None
    _current_vault_name_loaded = False

    # Flag avec TTL indiquant si la session est valide afin d'éviter
    # des répétition de "Session verify" auprès du serveur lors d'une commande
    _last_session_valid = None
    _last_session_check = 0.0


    PATH = APP_DIR / "account_state.json"

    @classmethod
    def _ensure_storage_dir(cls):
        cls.PATH.parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(cls.PATH.parent, 0o700)
        except Exception:
            pass

    # ============================================================
    # Lecture et écriture de l'état du compte (fichier local)
    # ============================================================

    @classmethod
    def _read(cls):
        logger = log.get_logger(CTX.ACCOUNT_STATE, user="")
        if not cls.PATH.exists():
            return None

        try:
            data = json.loads(cls.PATH.read_text())
        except Exception:
            cls.clear()
            logger.error("Unable to decode account_state.json, file inexistant or corrupted")
            notify_user("Local session data is invalid. Please log in again.")
            return None

        # Vérification de l'intégrité du fichier via l'agent
        integrity = data.get("integrity")
        if integrity and "value" in integrity:
            agent = AgentClient(autostart=False)
            if not agent.status():
                logger.warning("Agent unavailable for integrity check")
                cls.clear()
                return data

            data_no_integrity = {k: v for k, v in data.items() if k != "integrity"}
            mac_data = canonical_json(data_no_integrity).encode()

            # Comparaison de l'intégrité, si c'est pas bon, clear
            computed = agent.hmac(mac_data, logger)
            if not computed or computed.get("hmac") != integrity["value"]:
                logger.error("Integrity check failed for account_state.json")
                notify_user("Local account data is corrupted. You have been logged out.")
                cls.clear()
                return None

        return data
            


    @classmethod
    def save(cls, username, salt, public_key, private_key_block, session_block, pwd):
        logger = log.get_logger(CTX.ACCOUNT_STATE, username)
        cls._ensure_storage_dir()

        payload = {
            "username": username,
            "public_key": public_key,
            "salt": salt,
            "private_key": private_key_block,
            "session": session_block,
        }

        if not cls._persist_payload(payload, logger):
            return False

        # Sauvegarde de certaine valeur en cache
        cls._cached_username = username
        try:
            cls._cached_public_key = base64.b64decode(public_key)
        except Exception as exc:
            cls._cached_public_key = None
            logger.warning(f"Unable to cache public key: {exc}")
        cls._reset_session_cache()
        return True

    @classmethod
    def _persist_payload(cls, payload, logger):
        """Recalcule l'intégrité et écrit le fichier account_state.json."""
        agent = AgentClient(autostart=False)
        mac_data = canonical_json(payload).encode()
        mac_resp = agent.hmac(mac_data, logger)
        mac_value = mac_resp.get("hmac") if mac_resp else None

        if not mac_value:
            logger.error("Failed to compute integrity MAC via agent")
            return False

        payload_with_mac = dict(payload)
        payload_with_mac["integrity"] = {"value": mac_value, "algo": "HMAC-SHA256"}

        try:
            payload_json = json.dumps(payload_with_mac, indent=2)
            cls._ensure_storage_dir()
            fd = os.open(str(cls.PATH), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload_json)
        except Exception as exc:
            logger.error(f"Unable to persist account state: {exc}")
            return False

        return True

    @classmethod
    def _reset_session_cache(cls):
        cls._last_session_valid = None
        cls._last_session_check = 0.0
        cls.clear_cached_integrations()

    @classmethod
    def _remember_session_status(cls, status: bool):
        cls._last_session_valid = status
        cls._last_session_check = time.monotonic()
        return status

    @classmethod
    def _persist_current_vault(cls, vault_id: str | None, vault_name: str | None):
        data = cls._read()
        if not data:
            return False

        payload = {k: v for k, v in data.items() if k != "integrity"}
        if vault_id:
            payload["current_vault"] = vault_id
            if vault_name is not None:
                payload["current_vault_name"] = vault_name
            else:
                payload.pop("current_vault_name", None)
        else:
            payload.pop("current_vault", None)
            payload.pop("current_vault_name", None)

        username = payload.get("username") or cls._cached_username or ""
        logger = log.get_logger(CTX.ACCOUNT_STATE, username)
        return cls._persist_payload(payload, logger)

    @classmethod
    def clear(cls):
        if cls.PATH.exists():
            cls.PATH.unlink()
        cls._cached_username = None
        cls._cached_public_key = None
        cls._cached_session_id = None # Ne nettoie pas les bytes en mémoire comme la clé privée... cela peut être une amélioration
        cls.clear_private_key()
        cls.clear_vault_keys()
        cls._current_vault_id = None
        cls._current_vault_loaded = False
        cls._current_vault_name = None
        cls._current_vault_name_loaded = False
        cls._reset_session_cache()
        cls.clear_cached_integrations()

    # ============================================================
    # Gestion de session et récupération des infos utilisateur
    # ============================================================
    @classmethod
    def valid(cls):
        """Vérifie si la session locale existe et est encore valide côté serveur."""
        if cls._last_session_valid is not None:
            elapsed = time.monotonic() - cls._last_session_check
            if elapsed < SESSION_VALIDITY_TTL:
                return cls._last_session_valid

        current_user = cls.username()
        logger = log.get_logger(CTX.SESSION_VERIFY, current_user)
        sid = cls.session_id()
        if not sid:
            logger.debug("No local session ID available. Session is considered invalid")
            return cls._remember_session_status(False)

        session_payload = cls.session_payload()
        if session_payload is None:
            logger.debug("Unable to build session payload. Session is considered invalid")
            return cls._remember_session_status(False)

        # Vérifie auprès du serveur
        data = handle_resp(
            api_post("/session/verify", session_payload, user=current_user),
            required_fields=["username"],
            context=CTX.SESSION_VERIFY,
            user=current_user
        )
        if data is None:
            logger.warning(f"Local session '{sid[:8]}' invalid according to server, clearing local data")
            notify_user("Session invalid or expired. Please log in again.")
            cls.clear()
            return cls._remember_session_status(False)

        server_username_hash = data.get("username")
        expected_hash = session_payload.get("username_hash")
        if expected_hash and server_username_hash and expected_hash != server_username_hash:
            logger.error("Session username mismatch detected; clearing local data")
            notify_user("Local session data is inconsistent. Please log in again.")
            cls.clear()
            return cls._remember_session_status(False)

        return cls._remember_session_status(True)

    @classmethod
    def username(cls):
        """getter du nom d'utilisateur"""
        # Récupère le username du cache si existe
        if cls._cached_username is not None:
            return cls._cached_username
        
        # Sinon lis le username stocké sur le disque
        data = cls._read()
        if not data:
            return None
        username = data.get("username")
        if not username:
            return None
        cls._cached_username = username
        return cls._cached_username

    @classmethod
    def public_key(cls):
        """getter de la clé publique"""
        # Récupère la clé publique en cache
        if cls._cached_public_key is not None:
            return cls._cached_public_key
        
        # Sinon lit la clé pub stockée sur le disque
        data = cls._read()
        if not data:
            return None
        public_key_b64 = data.get("public_key")
        if not public_key_b64:
            return None
        try:
            cls._cached_public_key = base64.b64decode(public_key_b64)
            return cls._cached_public_key
        except Exception as e:
            log.get_logger(CTX.ACCOUNT_STATE, user=cls._cached_username or "").error(
                f"Invalid public key encoding in account_state.json: {e}"
            )
            return None
        
    @classmethod
    def session_payload(cls):
        session_id = cls.session_id()
        if not session_id:
            notify_user("No active session. Please log in.")
            return None
        payload = {"session_id": session_id}
        username = cls.username()
        if username:
            payload["username_hash"] = SHA256.new(username.encode()).hexdigest()
        return payload
        
    # ============================================================
    # Gestion de la clé privée : mémoire, cache et déchiffrement
    # ============================================================

    @classmethod
    def private_key(cls):
        """getter de la clé privée"""
        if cls._private_key is not None:
            return bytes(cls._private_key) 
        return cls._load_private_key_in_mem()
    
    @classmethod
    def set_private_key(cls, key_bytes):
        """setter de la clé privée"""
        cls._private_key = bytearray(key_bytes)

    @classmethod
    def clear_private_key(cls):
        """Clean propre de la clé privée en mémoire"""
        if cls._private_key is not None:
            key_obj = cls._private_key
            if isinstance(key_obj, bytearray):
                for i in range(len(key_obj)):
                    key_obj[i] = 0
        cls._private_key = None

    @classmethod
    def _load_private_key_in_mem(cls):
        """
        Recharge la clé privée chiffée du le disque lorsque le cache est vide.
        """
        return cls._load_secret_from_disk(
            field_name="private_key",
            cache_setter=cls.set_private_key,
            cache_value_transform=lambda decrypted: decrypted,
            return_transform=lambda: bytes(cls._private_key)
        )

    # ============================================================
    # Gestion de la session : cache et déchiffrement
    # ============================================================

    @classmethod
    def session_id(cls):
        """getter de l'id de session"""
        if cls._cached_session_id is not None:
            return cls._cached_session_id
        return cls._load_session_id_in_mem()

    @classmethod
    def set_session_id(cls, session_id: str):
        """setter de l'id de session"""
        cls._cached_session_id = session_id

    @classmethod
    def _load_session_id_in_mem(cls):
        """
        Recharge la session chiffrée du le disque lorsque le cache est vide.
        """
        return cls._load_secret_from_disk(
            field_name="session",
            cache_setter=cls.set_session_id,
            cache_value_transform=lambda decrypted: decrypted.decode(),
            return_transform=lambda: cls._cached_session_id
        )



    # ============================================================
    # Helpers cryptographiques & autres
    # ============================================================

    @classmethod
    def decrypt_secret(cls, enc_block_b64):
        """Déchiffre un bloc via l'agent actif."""
        agent = AgentClient(autostart=False)

        resp = agent.decrypt(
            enc_block_b64["enc"],
            enc_block_b64["nonce"],
            enc_block_b64["tag"]
        )
        if not resp or "plaintext" not in resp: return None

        return base64.b64decode(resp["plaintext"])
        
    @classmethod
    def encrypt_secret(cls, plaintext: bytes):
        """Chiffre un bloc via l'agent actif."""
        agent = AgentClient(autostart=False)
        payload = base64.b64encode(plaintext).decode()

        resp = agent.encrypt(payload)
        if not resp: return None

        return {
            "enc": resp["ciphertext"],
            "nonce": resp["nonce"],
            "tag": resp["tag"],
        }
    
    @classmethod
    def _load_secret_from_disk(cls, field_name, cache_setter, cache_value_transform, return_transform):
        """
        Mutualise la lecture/déchiffrement d'un secret stocké sur disque.
        """
        logger = log.get_logger(CTX.ACCOUNT_STATE, cls.username())
        data = cls._read()
        if not data:
            logger.debug("No local account state found")
            return None

        secret_block = data.get(field_name)
        if not secret_block:
            logger.error(f"Missing encrypted {field_name} in local account state")
            return None

        # Vérifie que l'agent est dispo
        if not AgentClient(autostart=False).status():
            logger.error("Agent is not running")
            notify_user("Secure agent is not running. Please log in again.")
            return None

        # Déchiffre via l'agent actif
        plaintext = cls.decrypt_secret(secret_block)
        if not plaintext:
            logger.error(f"Decryption failed for {field_name}. Session likely expired")
            notify_user("Secure agent session expired. Please log in again.")
            return None

        cache_value = cache_value_transform(plaintext)
        cache_setter(cache_value)
        cls._warm_related_secrets(data, field_name)
        return return_transform()

    @classmethod
    def _warm_related_secrets(cls, data, loaded_field):
        """
        Utilise le même mot de passe pour charger l'autre secret si nécessaire, afin d'éviter une seconde saisie utilisateur.
        """
        def _maybe_load(field_name, loader):
            secret_block = data.get(field_name)
            if not secret_block:
                return
            try:
                plaintext = cls.decrypt_secret(secret_block)
                loader(plaintext)
            except Exception:
                log.get_logger(CTX.DECRYPT, cls.username()).warning(
                    f"Unable to preload {field_name} from disk"
                )

        if loaded_field != "private_key" and cls._private_key is None:
            _maybe_load("private_key", cls.set_private_key)

        if loaded_field != "session" and cls._cached_session_id is None:
            def _set_session(plaintext):
                cls.set_session_id(plaintext.decode())
            _maybe_load("session", _set_session)

    # ============================================================
    # Gestion des intégrations (cache RAM uniquement)
    # ============================================================
    @classmethod
    def set_cached_integrations(cls, data: dict):
        cls._cached_integrations = dict(data)

    @classmethod
    def get_cached_integrations(cls) -> dict:
        return dict(cls._cached_integrations)

    @classmethod
    def clear_cached_integrations(cls):
        cls._cached_integrations.clear()

    # ============================================================
    # Bloc chiffré des intégrations (persisté dans account_state.json)
    # ============================================================
    @classmethod
    def set_integrations_block(cls, block: dict | None):
        """
        Enregistre le bloc chiffré des intégrations (tel que reçu du serveur) dans account_state.json.
        """
        data = cls._read()
        if data is None:
            return False

        payload = {k: v for k, v in data.items() if k != "integrity"}
        if block:
            payload["integrations"] = block
        else:
            payload.pop("integrations", None)

        username = payload.get("username") or cls._cached_username or ""
        logger = log.get_logger(CTX.ACCOUNT_STATE, username)
        return cls._persist_payload(payload, logger)

    @classmethod
    def integrations_block(cls):
        """
        Retourne le bloc chiffré des intégrations stocké localement (sans déchiffrer).
        """
        data = cls._read()
        if not data:
            return None
        return data.get("integrations")

    # ============================================================
    # Gestion des vaults (cache mémoire uniquement)
    # ============================================================

    @classmethod
    def set_vault_key(cls, vault_id: str, key_bytes: bytes):
        cls._vault_keys[vault_id] = bytearray(key_bytes)

    @classmethod
    def vault_key(cls, vault_id: str):
        key = cls._vault_keys.get(vault_id)
        if key is None:
            return None
        return bytes(key)

    @classmethod
    def clear_vault_keys(cls):
        if not cls._vault_keys:
            return
        for value in cls._vault_keys.values():
            if isinstance(value, bytearray):
                for idx in range(len(value)):
                    value[idx] = 0
        cls._vault_keys.clear()
    
    @classmethod
    def remove_vault_key(cls, vault_id: str):
        key = cls._vault_keys.pop(vault_id, None)
        if isinstance(key, bytearray):
            for idx in range(len(key)):
                key[idx] = 0

    @classmethod
    def set_current_vault(cls, vault_id: str, vault_name: str | None = None):
        cls._current_vault_id = vault_id
        cls._current_vault_loaded = True
        cls._current_vault_name = vault_name
        cls._current_vault_name_loaded = True
        if not cls._persist_current_vault(vault_id, vault_name):
            cls._current_vault_id = None
            cls._current_vault_loaded = True
            cls._current_vault_name = None
            cls._current_vault_name_loaded = True
            return False
        return True

    @classmethod
    def clear_current_vault(cls):
        cls._current_vault_id = None
        cls._current_vault_loaded = True
        cls._current_vault_name = None
        cls._current_vault_name_loaded = True
        return cls._persist_current_vault(None, None)

    @classmethod
    def current_vault(cls):
        if not cls._current_vault_loaded:
            cls._load_current_vault_from_disk()
        return cls._current_vault_id

    @classmethod
    def current_vault_name(cls):
        if not cls._current_vault_name_loaded:
            cls._load_current_vault_from_disk()
        return cls._current_vault_name

    @classmethod
    def _load_current_vault_from_disk(cls):
        data = cls._read()
        if not data:
            cls._current_vault_id = None
            cls._current_vault_name = None
        else:
            cls._current_vault_id = data.get("current_vault")
            cls._current_vault_name = data.get("current_vault_name")
        cls._current_vault_loaded = True
        cls._current_vault_name_loaded = True
        return cls._current_vault_id
