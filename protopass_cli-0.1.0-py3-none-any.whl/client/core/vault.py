import base64, uuid, os, json
from datetime import datetime, timezone
from .account_state import AccountState
from ..utils import logger as log
from ..utils.common import get_id_by_index, fetch_vaults
from ..utils.logger import CTX, notify_user
from ..utils.network import api_post, handle_resp
from ..utils.display import render_table, format_timestamp, prompt_field, verify_prompt
from ..utils.crypto import (
    encrypt_b64_block,
    decrypt_b64_block,
    sign_vault_key,
    wrap_vault_key,
    unwrap_vault_key,
    b64_block_from_bytes,
    bytes_from_b64_block,
)

def _fetch_vault_rows():
    """
    Récupère tous les vaults depuis le serveur, déchiffre leurs métadonnées
    et retourne une liste de lignes prêtes pour l'affichage dans vault list
    """
    # récupération du contexte utilisateur actuel
    session_payload = AccountState.session_payload()
    if session_payload is None:
        return None
    current_user = AccountState.username()
    logger = log.get_logger(CTX.VAULT_LIST, current_user)
    
    # Récupère tous les vaults
    vaults = fetch_vaults(session_payload, current_user, CTX.VAULT_LIST)
    if len(vaults) == 0:
        notify_user("No vaults found.")
        return None
    
    # récupération de la clé privée locale pour déchiffrer les données
    private_key = AccountState.private_key()
    if private_key is None:
        logger.error("No valid private key in account state (memory).")
        notify_user("Unable to decrypt vaults with current keys.")
        return None
    
    # boucle sur chaque coffre pour construire les lignes d'affichage
    rows = []
    for idx, vault in enumerate(vaults, start=1):
        vault_id = vault.get("vault_id", "unknown")
        try:
            # 1) déchiffre la vault_key avec la private_key
            vault_key_enc = base64.b64decode(vault["key_enc"])
            vault_key = unwrap_vault_key(private_key, vault_key_enc)

            # 2) déchiffrement des métadonnées
            plaintext = decrypt_b64_block(vault_key, vault.get("metadata"))

            # met la clé de ce vault en cache RAM
            AccountState.set_vault_key(vault_id, vault_key)

            metadata = json.loads(plaintext)
            vault_name = metadata.get("name")
            description = metadata.get("description")
            created_at = metadata.get("created_at")
            created_display = format_timestamp(created_at) if created_at else "-"

        except Exception as e:
            logger.error(f"Failed to decrypt vault '{vault_id[:8]}': {e}")
            continue

        # ajoute le nouveau vault lu dans une ligne
        rows.append({
            "idx": str(idx),
            "name": vault_name or "-",
            "desc": description or "-",
            "created": created_display,
            "uuid": vault["vault_id"]
        })

    return rows


def ensure_vault_key(vault_id: str, logger=None):
    """
    Garantit que la clé du vault est disponible en mémoire.
    Rafraîchit le cache via _fetch_vault_rows si nécessaire.
    """

    key = AccountState.vault_key(vault_id)
    if key is not None:
        return key

    rows = _fetch_vault_rows()
    if not rows:
        if logger:
            logger.error("Unable to reload vault key cache.")
        return None

    return AccountState.vault_key(vault_id)

def delete_vault(args):
    # récupération du contexte utilisateur actuel
    session_payload = AccountState.session_payload()
    if session_payload is None:
        return
    current_user = AccountState.username()
    logger = log.get_logger(CTX.VAULT_DELETE, current_user)
    
    rows = _fetch_vault_rows()
    if not rows:
        return
    
    # Trouver le vault via l'index
    vault_id_to_del, vault_name_to_del = get_id_by_index(args.index, rows, logger)
    if vault_id_to_del is None:
        return

    notify_user(f"found vault id to del : {vault_id_to_del}")

    # Envoie les informations du nouveau vault au serveur
    payload = {
        **session_payload,
        "vault_id": vault_id_to_del,
    }
    resp = api_post("/vault/delete", payload, user=current_user)
    data = handle_resp(
        resp,
        required_fields=["vault_id"],
        context=CTX.VAULT_DELETE,
        user=current_user
    )
    if data is None:
        notify_user("Vault deletion failed. See logs for details.")
        return
    
    # Nettoie l'état local si on supprime le vault actuellement sélectionné
    current_selected = AccountState.current_vault()
    if current_selected == vault_id_to_del:
        AccountState.clear_current_vault()
    AccountState.remove_vault_key(vault_id_to_del)

    notify_user(f"Vault '{vault_name_to_del}' deleted successfully.")

def select_vault(args):
    current_user = AccountState.username()
    logger = log.get_logger(CTX.VAULT_SELECT, current_user)

    # On récupère les lignes (et, par effet de bord, on remplit _vault_keys)
    rows = _fetch_vault_rows()
    if not rows:
        return

    # Retrouve l'UUID à partir de l'index
    vault_id, vault_name = get_id_by_index(args.index, rows, logger)
    if vault_id is None or vault_name is None:
        return

    # Essaie de récupérer la clé en RAM (si elle y est déjà)
    vault_key = ensure_vault_key(vault_id, logger)
    if vault_key is None:
        return
    
    # Maj du vault courant
    if not AccountState.set_current_vault(vault_id, vault_name):
        notify_user("Unable to select vault: secure agent unavailable. Please log in again.")
        return

    notify_user(f"Vault {args.index} [{vault_name}] is now selected.")

    
def list_vaults(_args):
    if not AccountState.valid():
        print("Please login to list vaults.")
        return

    rows = _fetch_vault_rows()
    if not rows:
        return
    
    # Ajout du marqueur "*" sur le vault sélectionné
    current = AccountState.current_vault()
    if current:
        for row in rows:
            if row["uuid"] == current:
                row["idx"] = "*" + row["idx"]
                break

    columns = [
        ("idx", "#", 3),
        ("name", "Name", 15),
        ("desc", "Description", 40),
        ("created", "Created", 17),
    ]
    print(render_table(rows, columns))

def create_vault(_args):
    # récupération du contexte utilisateur actuel
    session_payload = AccountState.session_payload()
    if session_payload is None:
        return
    current_user = AccountState.username()
    logger = log.get_logger(CTX.VAULT_CREATE, current_user)
    
    public_key = AccountState.public_key()
    private_key = AccountState.private_key()
    if current_user is None or public_key is None or private_key is None:
        notify_user(
            "Vault creation aborted: local account state is invalid.\n"
            "Run 'logout' then 'login' to regenerate your keys."
        )
        return

    # Mode CLI si options fournies, sinon mode interactif
    if hasattr(_args, "name") and _args.name:
        vault_name = _args.name
        if verify_prompt(vault_name, "Vault name", 15, False, logger) is False:
            return
    else:
        vault_name = prompt_field("Vault name", 15, False, logger)
    if hasattr(_args, "description") and _args.description:
        description = _args.description
        if verify_prompt(description, "Description", 40, True, logger) is False:
            return
    else:
        description = prompt_field("Description", 40, True, logger)

    # Création du JSON
    now = datetime.now(timezone.utc).isoformat()
    metadata_plain = {
        "name": vault_name,
        "description": description,
        "created_at": now,
    }
    metadata_plaintext = json.dumps(metadata_plain)

    # Génère un UUID pour le vault
    vault_id = str(uuid.uuid4())
    # Génère une clé symétrique de 256bits pour le vault
    vault_key = os.urandom(32)

    # signature de la clé du vault avec la clé privée de l'utilisateur
    vault_signature = sign_vault_key(private_key, vault_key)

    # chiffre la clé du vault avec la clé publique de l'utilisateur
    vault_key_enc = wrap_vault_key(public_key, vault_key)

    # chiffrement des métadonnées du vault avec la vault_key
    metadata_blob = encrypt_b64_block(vault_key, metadata_plaintext.encode())

    #
    # Pas d'items créés pour l'instant
    #
    
    # Envoie les informations du nouveau vault au serveur
    payload = {
        **session_payload,
        "vault_id": vault_id,
        "key_enc": base64.b64encode(vault_key_enc).decode(),
        "signature": base64.b64encode(vault_signature).decode(),
        "metadata": metadata_blob,
        "items": []
    }
    resp = api_post("/vault/create", payload, user=current_user)
    data = handle_resp(
        resp,
        required_fields=["vault_id"],
        context=CTX.VAULT_CREATE,
        user=current_user
    )
    if data is None:
        notify_user("Vault creation failed. See logs for details.")
        return

    notify_user(f"Vault '{vault_name}' created successfully.")
